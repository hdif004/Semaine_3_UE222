<?php

namespace ContainerTip04KQ;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/src/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder4d7f8 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerd3446 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties1bf68 = [
        
    ];

    public function getConnection()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getConnection', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getMetadataFactory', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getExpressionBuilder', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'beginTransaction', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getCache', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getCache();
    }

    public function transactional($func)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'transactional', array('func' => $func), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'wrapInTransaction', array('func' => $func), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'commit', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->commit();
    }

    public function rollback()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'rollback', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getClassMetadata', array('className' => $className), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'createQuery', array('dql' => $dql), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'createNamedQuery', array('name' => $name), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'createQueryBuilder', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'flush', array('entity' => $entity), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'clear', array('entityName' => $entityName), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->clear($entityName);
    }

    public function close()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'close', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->close();
    }

    public function persist($entity)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'persist', array('entity' => $entity), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'remove', array('entity' => $entity), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->remove($entity);
    }

    public function refresh($entity, ?int $lockMode = null)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'refresh', array('entity' => $entity, 'lockMode' => $lockMode), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->refresh($entity, $lockMode);
    }

    public function detach($entity)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'detach', array('entity' => $entity), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'merge', array('entity' => $entity), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getRepository', array('entityName' => $entityName), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'contains', array('entity' => $entity), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getEventManager', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getConfiguration', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'isOpen', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getUnitOfWork', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getProxyFactory', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'initializeObject', array('obj' => $obj), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->initializeObject($obj);
    }

    public function isUninitializedObject($obj) : bool
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'isUninitializedObject', array('obj' => $obj), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->isUninitializedObject($obj);
    }

    public function getFilters()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'getFilters', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'isFiltersStateClean', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'hasFilters', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return $this->valueHolder4d7f8->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerd3446 = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, ?\Doctrine\Common\EventManager $eventManager = null)
    {
        static $reflection;

        if (! $this->valueHolder4d7f8) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder4d7f8 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder4d7f8->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, '__get', ['name' => $name], $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        if (isset(self::$publicProperties1bf68[$name])) {
            return $this->valueHolder4d7f8->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4d7f8;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder4d7f8;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4d7f8;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder4d7f8;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, '__isset', array('name' => $name), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4d7f8;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder4d7f8;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, '__unset', array('name' => $name), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4d7f8;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder4d7f8;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, '__clone', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        $this->valueHolder4d7f8 = clone $this->valueHolder4d7f8;
    }

    public function __sleep()
    {
        $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, '__sleep', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;

        return array('valueHolder4d7f8');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerd3446 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerd3446;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerd3446 && ($this->initializerd3446->__invoke($valueHolder4d7f8, $this, 'initializeProxy', array(), $this->initializerd3446) || 1) && $this->valueHolder4d7f8 = $valueHolder4d7f8;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder4d7f8;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder4d7f8;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
